import { useState, useEffect, useCallback } from "react";

// ─── Constants ────────────────────────────────────────────────────────
const PLATFORMS = ["TikTok", "Instagram Reels", "YouTube Shorts"];

const PROFIT_TIERS = {
  "🔥 VIRAL": { color: "#FF4444", bg: "#FF44441A", min: 90 },
  "📈 HIGH":  { color: "#FF8C00", bg: "#FF8C001A", min: 70 },
  "✅ SOLID": { color: "#00C853", bg: "#00C8531A", min: 50 },
  "💤 LOW":   { color: "#888",    bg: "#1A1A1A",   min: 0  },
};

const STREAMERS = [
  {
    name: "DeentheGreat", category: "IRL / Funny / Boxing", avgViewers: "12.4K", peakViewers: "41.5K",
    clipScore: 93, trend: "+136K followers/30d", platform: "Kick", followerCount: "246.9K",
    monetizationNotes: "Explosive growth — 136K new followers in 30 days. IRL chaos, boxing crossover, celebrity collabs = constant viral moments. Kick has zero copyright strikes.",
    clipTypes: ["Wild IRL moments", "Celebrity collab reactions", "Boxing trash talk", "Giveaway chaos", "Crash Out Boys crew content"],
    kickUrl: "https://kick.com/deenthegreat/clips",
  },
  {
    name: "xQc", category: "IRL / Gambling / Reactions", avgViewers: "85K", peakViewers: "200K+",
    clipScore: 96, trend: "+12%", platform: "Twitch", followerCount: "12M+",
    monetizationNotes: "Reaction clips get 2-5M TikTok views. Gambling + IRL moments = massive engagement. Most clipped streamer on the internet.",
    clipTypes: ["Gambling big wins/losses", "Rage moments", "IRL reactions", "Drama clips", "Funny chat interactions"],
    kickUrl: "https://www.twitch.tv/xqc/clips",
  },
  {
    name: "Speed", category: "Rage / Reactions", avgViewers: "78K", peakViewers: "150K+",
    clipScore: 91, trend: "+18%", platform: "Kick/YouTube", followerCount: "5M+",
    monetizationNotes: "Rage clips are YouTube Shorts magnets. His audience actively clips and reposts — easy content. Younger demographic = high share rate.",
    clipTypes: ["Rage quits", "Screaming reactions", "IRL stunts", "Challenge fails", "Celebrity encounters"],
    kickUrl: "https://kick.com/ishowspeed/clips",
  },
  {
    name: "Adin Ross", category: "Celebrity Collabs / IRL", avgViewers: "67K", peakViewers: "300K+",
    clipScore: 88, trend: "+22%", platform: "Kick", followerCount: "8M+",
    monetizationNotes: "Celebrity guest clips get picked up by mainstream media. Easy cross-platform reposts. His fans are extremely loyal clippers.",
    clipTypes: ["Celebrity guest moments", "IRL wild moments", "Prank reactions", "Drama moments", "Music collabs"],
    kickUrl: "https://kick.com/adinross/clips",
  },
  {
    name: "Tyler1", category: "League of Legends / Rage", avgViewers: "55K", peakViewers: "100K",
    clipScore: 82, trend: "+9%", platform: "Twitch", followerCount: "5.5M",
    monetizationNotes: "Rage moments get clipped constantly. Gaming audience = high ad CTR on YouTube Shorts. Consistent daily content.",
    clipTypes: ["Rage quits", "Insane plays", "Trash talk", "Duo fails", "Chat battles"],
    kickUrl: "https://www.twitch.tv/tyler1/clips",
  },
];

// Suggested clip ideas per streamer based on what historically goes viral
const CLIP_SUGGESTIONS = {
  "DeentheGreat": [
    { title: "Crash Out Boys IRL Chaos", type: "IRL", viralScore: 95, why: "Group IRL content with his crew gets massive engagement. Look for fights, wild moments, unexpected reactions.", where: "kick.com/deenthegreat/clips — sort by 'Most Viewed'", estimatedViews: "500K–2M" },
    { title: "Boxing Trash Talk Moment", type: "Boxing/Hype", viralScore: 91, why: "His boxing persona + trash talk clips perform huge on TikTok. Short, punchy, energy-filled clips.", where: "kick.com/deenthegreat/clips — filter by 'IRL'", estimatedViews: "300K–1M" },
    { title: "Giveaway Reaction / Winner Moment", type: "Emotional", viralScore: 88, why: "He does giveaways daily. Winner reaction clips are shareable and get comment section engagement.", where: "Recent VODs on kick.com/deenthegreat/videos", estimatedViews: "200K–800K" },
    { title: "Wild Guest / Celebrity Appearance", type: "Collab", viralScore: 94, why: "Any clip with a known name alongside Deen goes viral fast — mainstream media picks these up.", where: "kick.com/deenthegreat/clips — look for multi-person clips", estimatedViews: "1M–5M" },
    { title: "Unexpected / Shocking IRL Moment", type: "Shock", viralScore: 97, why: "His most viral clip ever was a police encounter. Any unexpected real-life situation = instant virality.", where: "kick.com/deenthegreat/clips — sort last 7 days", estimatedViews: "1M–10M+" },
  ],
  "xQc": [
    { title: "Massive Gambling Win or Loss", type: "Gambling", viralScore: 94, why: "High emotion, stakes are visible on screen, audiences love the volatility.", where: "twitch.tv/xqc/clips — filter Slots/Casino category", estimatedViews: "500K–3M" },
    { title: "Unhinged Chat Reaction", type: "Funny", viralScore: 89, why: "xQc reading chat and losing it is a core clip format his fans love.", where: "twitch.tv/xqc/clips — sort by views", estimatedViews: "300K–1M" },
    { title: "IRL Meltdown Moment", type: "Rage", viralScore: 92, why: "His rage/meltdown clips consistently hit 1M+ on TikTok. Short and punchy works best.", where: "Recent clips sorted by views", estimatedViews: "500K–2M" },
  ],
  "Speed": [
    { title: "Full Send Rage Quit", type: "Rage", viralScore: 96, why: "Speed's rage is legendary. These clips get shared millions of times across every platform.", where: "kick.com/ishowspeed/clips — sort Most Viewed", estimatedViews: "1M–5M" },
    { title: "IRL Street Moment", type: "IRL", viralScore: 91, why: "When Speed goes outside, chaos follows. These crossover to mainstream audiences.", where: "Recent VODs — look for IRL streams", estimatedViews: "500K–2M" },
  ],
  "default": [
    { title: "Most Viewed Clip This Week", type: "Top Clip", viralScore: 85, why: "The most viewed clip of the week is already proven content — clip it before everyone else does.", where: "Visit their clips page and sort by 'This Week'", estimatedViews: "200K–1M" },
    { title: "Emotional / Reaction Moment", type: "Emotional", viralScore: 80, why: "Emotions drive shares. Look for genuine surprise, laughter, or shock moments.", where: "Browse recent VODs for standout moments", estimatedViews: "100K–500K" },
  ],
};

// ─── Helpers ──────────────────────────────────────────────────────────
// eslint-disable-next-line no-unused-vars
function getProfitTier(score) {
  for (const [label, data] of Object.entries(PROFIT_TIERS)) {
    if (score >= data.min) return { label, ...data };
  }
  return { label: "💤 LOW", color: "#888", bg: "#1A1A1A" };
}

async function callClaude(prompt, maxTokens = 1200) {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: maxTokens,
      messages: [{ role: "user", content: prompt }],
    }),
  });
  const data = await response.json();
  return data.content?.[0]?.text || "";
}

function formatTime(iso) {
  return new Date(iso).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
}

// ─── Small UI pieces ──────────────────────────────────────────────────
// eslint-disable-next-line no-unused-vars
function Badge({ label, color, bg }) {
  return (
    <span style={{ background: bg, color, border: `1px solid ${color}44`, borderRadius: 6, padding: "3px 9px", fontSize: 11, fontWeight: 700 }}>
      {label}
    </span>
  );
}

function ScoreRing({ score }) {
  const r = 38, circ = 2 * Math.PI * r;
  const color = score >= 80 ? "#FF4444" : score >= 65 ? "#FF8C00" : score >= 50 ? "#00C853" : "#555";
  return (
    <div style={{ position: "relative", width: 90, height: 90, flexShrink: 0 }}>
      <svg width={90} height={90} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={45} cy={45} r={r} fill="none" stroke="#1A1A2E" strokeWidth={9} />
        <circle cx={45} cy={45} r={r} fill="none" stroke={color} strokeWidth={9}
          strokeDasharray={`${(score / 100) * circ} ${circ}`} strokeLinecap="round" />
      </svg>
      <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
        <div style={{ color, fontSize: 20, fontWeight: 900, lineHeight: 1 }}>{score}</div>
        <div style={{ color: "#5050A0", fontSize: 9, fontWeight: 700 }}>VIRAL</div>
      </div>
    </div>
  );
}

function SignalBar({ label, score, emoji }) {
  const color = score >= 80 ? "#FF4444" : score >= 60 ? "#FF8C00" : score >= 40 ? "#00C853" : "#555";
  return (
    <div style={{ marginBottom: 9 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
        <span style={{ color: "#9090C0", fontSize: 12 }}>{emoji} {label}</span>
        <span style={{ color, fontSize: 12, fontWeight: 700 }}>{score}/100</span>
      </div>
      <div style={{ background: "#1A1A2E", borderRadius: 99, height: 5 }}>
        <div style={{ width: `${score}%`, height: "100%", borderRadius: 99, background: `linear-gradient(90deg, ${color}88, ${color})`, transition: "width 0.7s ease" }} />
      </div>
    </div>
  );
}

function CaptionCard({ platform, caption, onCopy, copied }) {
  const icons = { TikTok: "🎵", "Instagram Reels": "📸", "YouTube Shorts": "▶️" };
  return (
    <div style={{ background: "#1A1A2E", border: "1px solid #2A2A4A", borderRadius: 12, padding: "14px 16px", marginBottom: 10 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
        <span style={{ color: "#9090C0", fontSize: 12, fontWeight: 700 }}>{icons[platform]} {platform.toUpperCase()}</span>
        <button onClick={() => onCopy(caption, platform)} style={{
          background: copied === platform ? "#00C853" : "#7C3AED", color: "#fff",
          border: "none", borderRadius: 6, padding: "4px 12px", fontSize: 12, fontWeight: 700, cursor: "pointer",
        }}>{copied === platform ? "✓ Copied!" : "Copy"}</button>
      </div>
      <p style={{ color: "#E0E0FF", fontSize: 13, lineHeight: 1.6, margin: 0, whiteSpace: "pre-wrap" }}>{caption}</p>
    </div>
  );
}

// ─── Clip Suggestion Card ─────────────────────────────────────────────
function ClipSuggestionCard({ clip, onDraft, onGenerate, isDrafted, isGenerating }) {
  const tierColor = clip.viralScore >= 90 ? "#FF4444" : clip.viralScore >= 80 ? "#FF8C00" : "#00C853";
  return (
    <div style={{ background: "#12121E", border: `1px solid ${isDrafted ? "#00C85340" : "#1E1E3A"}`, borderRadius: 14, padding: 16, marginBottom: 12 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10, gap: 10 }}>
        <div style={{ flex: 1 }}>
          <div style={{ color: "#fff", fontWeight: 800, fontSize: 15, marginBottom: 3 }}>{clip.title}</div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            <span style={{ background: "#1A1A3E", color: "#7C3AED", borderRadius: 5, padding: "2px 8px", fontSize: 11, fontWeight: 600 }}>{clip.type}</span>
            <span style={{ background: tierColor + "22", color: tierColor, borderRadius: 5, padding: "2px 8px", fontSize: 11, fontWeight: 700 }}>
              🔥 {clip.viralScore}/100
            </span>
            <span style={{ background: "#0D1A0D", color: "#00C853", borderRadius: 5, padding: "2px 8px", fontSize: 11, fontWeight: 600 }}>
              Est. {clip.estimatedViews}
            </span>
          </div>
        </div>
      </div>

      <div style={{ background: "#0D0D1A", borderRadius: 8, padding: "10px 12px", marginBottom: 10 }}>
        <div style={{ color: "#5050A0", fontSize: 10, fontWeight: 700, marginBottom: 3 }}>💡 WHY IT'LL POP</div>
        <div style={{ color: "#9090C0", fontSize: 12, lineHeight: 1.5 }}>{clip.why}</div>
      </div>

      <div style={{ background: "#0A0A18", borderRadius: 8, padding: "8px 12px", marginBottom: 12 }}>
        <div style={{ color: "#5050A0", fontSize: 10, fontWeight: 700, marginBottom: 3 }}>📍 WHERE TO FIND IT</div>
        <div style={{ color: "#6060C0", fontSize: 12 }}>{clip.where}</div>
      </div>

      <div style={{ display: "flex", gap: 8 }}>
        <button onClick={() => onGenerate(clip)} disabled={isGenerating} style={{
          flex: 1, background: isGenerating ? "#1A1A3E" : "linear-gradient(135deg, #7C3AED, #4F46E5)",
          color: "#fff", border: "none", borderRadius: 8, padding: "9px", fontWeight: 700, fontSize: 13, cursor: isGenerating ? "not-allowed" : "pointer",
        }}>
          {isGenerating ? "⚡ Writing..." : "✨ Generate Captions"}
        </button>
        <button onClick={() => onDraft(clip)} style={{
          background: isDrafted ? "#0D1A0D" : "#12121E",
          color: isDrafted ? "#00C853" : "#5050A0",
          border: `1px solid ${isDrafted ? "#00C85340" : "#2A2A4A"}`,
          borderRadius: 8, padding: "9px 14px", fontWeight: 700, fontSize: 13, cursor: "pointer",
        }}>
          {isDrafted ? "✓ Saved" : "+ Draft"}
        </button>
      </div>
    </div>
  );
}

// ─── Draft Queue Item ─────────────────────────────────────────────────
function DraftItem({ draft, onRemove, onCopyCaptions }) {
  const [expanded, setExpanded] = useState(false);
  const [copied, setCopied] = useState(null);

  const handleCopy = (text, plat) => {
    navigator.clipboard.writeText(text);
    setCopied(plat);
    setTimeout(() => setCopied(null), 2000);
  };

  const timeUntil = () => {
    const diff = new Date(draft.postAt) - new Date();
    if (diff < 0) return "Post now!";
    const h = Math.floor(diff / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    return h > 0 ? `In ${h}h ${m}m` : `In ${m}m`;
  };

  const isReady = new Date(draft.postAt) <= new Date();

  return (
    <div style={{
      background: isReady ? "#0D1A0D" : "#12121E",
      border: `1px solid ${isReady ? "#00C85350" : "#1E1E3A"}`,
      borderRadius: 14, padding: 16, marginBottom: 10,
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 10 }}>
        <div style={{ flex: 1 }}>
          <div style={{ color: "#fff", fontWeight: 700, fontSize: 14 }}>{draft.clipTitle}</div>
          <div style={{ color: "#5050A0", fontSize: 12, marginTop: 2 }}>{draft.streamer} · {draft.platform}</div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ color: isReady ? "#00C853" : "#FF8C00", fontWeight: 800, fontSize: 13 }}>{timeUntil()}</div>
          <div style={{ color: "#404060", fontSize: 11 }}>{formatTime(draft.postAt)}</div>
        </div>
      </div>

      <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
        <button onClick={() => setExpanded(!expanded)} style={{
          flex: 1, background: "#1A1A2E", color: "#9090C0", border: "1px solid #2A2A4A",
          borderRadius: 8, padding: "7px", fontSize: 12, fontWeight: 600, cursor: "pointer",
        }}>
          {expanded ? "▲ Hide Captions" : "▼ View Captions"}
        </button>
        <button onClick={() => onRemove(draft.id)} style={{
          background: "transparent", color: "#FF444488", border: "1px solid #FF444430",
          borderRadius: 8, padding: "7px 12px", fontSize: 12, cursor: "pointer",
        }}>✕</button>
      </div>

      {expanded && draft.captions && (
        <div style={{ marginTop: 12 }}>
          {PLATFORMS.map(p => draft.captions[p] && (
            <CaptionCard key={p} platform={p} caption={draft.captions[p]} onCopy={handleCopy} copied={copied} />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Clip Predictor ───────────────────────────────────────────────────
function ClipPredictor({ onSaveToDraft }) {
  const [clipDesc, setClipDesc] = useState("");
  const [streamer, setStreamer] = useState("DeentheGreat");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const analyze = async () => {
    if (!clipDesc.trim()) { setError("Describe the clip first."); return; }
    setError(""); setLoading(true); setResult(null);
    const prompt = `You are a viral clip analyst. Score this clip idea vs average performance.

Streamer: ${streamer}
Clip: ${clipDesc}

Respond ONLY in JSON, no extra text:
{
  "overallScore": <0-100>,
  "verdict": "<one punchy sentence>",
  "recommendation": "<one actionable sentence>",
  "signals": { "emotionalHook": <0-100>, "shareability": <0-100>, "watchTime": <0-100>, "trendAlignment": <0-100>, "audienceSize": <0-100>, "monetizationPotential": <0-100> },
  "bestPlatform": "<TikTok|Instagram Reels|YouTube Shorts>",
  "bestTimeToPost": "<e.g. 7-9pm EST weekdays>",
  "redFlags": "<comma list or None>",
  "greenFlags": "<comma list>"
}`;
    try {
      const raw = await callClaude(prompt);
      setResult(JSON.parse(raw.replace(/```json|```/g, "").trim()));
    } catch { setError("Try rephrasing the description."); }
    setLoading(false);
  };

  const signals = [
    { key: "emotionalHook", label: "Emotional Hook", emoji: "🎣" },
    { key: "shareability", label: "Shareability", emoji: "🔁" },
    { key: "watchTime", label: "Watch Time", emoji: "⏱️" },
    { key: "trendAlignment", label: "Trend Alignment", emoji: "📈" },
    { key: "audienceSize", label: "Audience Reach", emoji: "👥" },
    { key: "monetizationPotential", label: "Monetization", emoji: "💰" },
  ];

  return (
    <div style={{ maxWidth: 800, margin: "0 auto", padding: 20 }}>
      <h2 style={{ color: "#E0E0FF", fontFamily: "sans-serif", margin: "0 0 6px" }}>🎯 Clip Performance Predictor</h2>
      <p style={{ color: "#5050A0", fontSize: 13, margin: "0 0 20px" }}>Describe any clip — AI scores it across 6 viral signals before you invest time clipping it.</p>

      <div style={{ background: "#12121E", border: "1px solid #2A2A4A", borderRadius: 14, padding: 18, marginBottom: 16 }}>
        <label style={{ color: "#5050A0", fontSize: 11, fontWeight: 700, display: "block", marginBottom: 5 }}>STREAMER</label>
        <select value={streamer} onChange={e => setStreamer(e.target.value)} style={{
          width: "100%", background: "#0A0A12", border: "1px solid #2A2A4A", borderRadius: 8,
          padding: "9px 12px", color: "#E0E0FF", fontSize: 13, marginBottom: 12, outline: "none",
        }}>
          {STREAMERS.map(s => <option key={s.name} value={s.name}>{s.name}</option>)}
        </select>

        <label style={{ color: "#5050A0", fontSize: 11, fontWeight: 700, display: "block", marginBottom: 5 }}>DESCRIBE THE CLIP ✱</label>
        <textarea value={clipDesc} onChange={e => setClipDesc(e.target.value)} rows={3}
          placeholder={`e.g. "Deen and his crew get into a wild situation at a party, crowd freaks out, ends with Deen laughing uncontrollably"`}
          style={{ width: "100%", boxSizing: "border-box", background: "#0A0A12", border: "1px solid #2A2A4A", borderRadius: 8, padding: "9px 12px", color: "#E0E0FF", fontSize: 13, outline: "none", fontFamily: "inherit", resize: "vertical" }} />

        {error && <div style={{ color: "#FF4444", fontSize: 12, margin: "8px 0" }}>⚠️ {error}</div>}
        <button onClick={analyze} disabled={loading} style={{
          width: "100%", marginTop: 12,
          background: loading ? "#1A1A3E" : "linear-gradient(135deg, #7C3AED, #4F46E5)",
          color: "#fff", border: "none", borderRadius: 10, padding: "12px", fontWeight: 800, fontSize: 14, cursor: loading ? "not-allowed" : "pointer",
        }}>
          {loading ? "⚡ Analyzing..." : "🔍 Predict Viral Potential"}
        </button>
      </div>

      {result && (
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div style={{ background: "#12121E", border: "1px solid #2A2A4A", borderRadius: 14, padding: 20, display: "flex", gap: 20, alignItems: "flex-start", flexWrap: "wrap" }}>
            <ScoreRing score={result.overallScore} />
            <div style={{ flex: 1, minWidth: 180 }}>
              <div style={{ color: "#5050A0", fontSize: 10, fontWeight: 700, marginBottom: 6 }}>AI VERDICT</div>
              <div style={{ color: "#E0E0FF", fontSize: 15, fontWeight: 600, lineHeight: 1.5, marginBottom: 12 }}>{result.verdict}</div>
              <div style={{ color: "#5050A0", fontSize: 10, fontWeight: 700, marginBottom: 4 }}>RECOMMENDATION</div>
              <div style={{ color: "#9090C0", fontSize: 13, lineHeight: 1.5, marginBottom: 14 }}>{result.recommendation}</div>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                <div style={{ background: "#1A1A3E", borderRadius: 8, padding: "7px 10px" }}>
                  <div style={{ color: "#5050A0", fontSize: 9, fontWeight: 700 }}>BEST PLATFORM</div>
                  <div style={{ color: "#7C3AED", fontSize: 12, fontWeight: 700 }}>{result.bestPlatform}</div>
                </div>
                <div style={{ background: "#1A1A3E", borderRadius: 8, padding: "7px 10px" }}>
                  <div style={{ color: "#5050A0", fontSize: 9, fontWeight: 700 }}>BEST TIME</div>
                  <div style={{ color: "#7C3AED", fontSize: 12, fontWeight: 700 }}>{result.bestTimeToPost}</div>
                </div>
              </div>
            </div>
          </div>

          <div style={{ background: "#12121E", border: "1px solid #2A2A4A", borderRadius: 14, padding: 18 }}>
            <div style={{ color: "#5050A0", fontSize: 10, fontWeight: 700, marginBottom: 12 }}>📊 SIGNAL BREAKDOWN</div>
            {signals.map(s => <SignalBar key={s.key} label={s.label} emoji={s.emoji} score={result.signals[s.key] ?? 50} />)}
          </div>

          <div style={{ display: "flex", gap: 10 }}>
            <div style={{ flex: 1, background: "#0D1A0D", border: "1px solid #00C85330", borderRadius: 12, padding: "14px 16px" }}>
              <div style={{ color: "#00C853", fontSize: 10, fontWeight: 700, marginBottom: 6 }}>✅ GREEN FLAGS</div>
              {result.greenFlags.split(",").map((f, i) => <div key={i} style={{ color: "#509050", fontSize: 12, marginBottom: 3 }}>• {f.trim()}</div>)}
            </div>
            <div style={{ flex: 1, background: "#1A0D0D", border: "1px solid #FF444430", borderRadius: 12, padding: "14px 16px" }}>
              <div style={{ color: "#FF4444", fontSize: 10, fontWeight: 700, marginBottom: 6 }}>🚩 RED FLAGS</div>
              {result.redFlags === "None"
                ? <div style={{ color: "#805050", fontSize: 12 }}>None detected</div>
                : result.redFlags.split(",").map((f, i) => <div key={i} style={{ color: "#905050", fontSize: 12, marginBottom: 3 }}>• {f.trim()}</div>)}
            </div>
          </div>
        </div>
      )}

      {!result && !loading && (
        <div style={{ textAlign: "center", padding: "50px 20px", color: "#252540" }}>
          <div style={{ fontSize: 48, marginBottom: 10 }}>🎯</div>
          <div style={{ fontSize: 14 }}>Describe any clip above to see its viral prediction</div>
        </div>
      )}
    </div>
  );
}

// ─── Clip Suggestions Tab ─────────────────────────────────────────────
function ClipSuggestions({ drafts, onAddDraft, streamers }) {
  const streamerList = streamers && streamers.length > 0 ? streamers : STREAMERS;
  const [activeStreamer, setActiveStreamer] = useState(streamerList[0]);

  // Update active streamer when list refreshes
  useEffect(() => {
    if (streamerList.length > 0) {
      setActiveStreamer(s => streamerList.find(x => x.name === s?.name) || streamerList[0]);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [streamers]);
  const [generatingId, setGeneratingId] = useState(null);
  const [captions, setCaptions] = useState({});
  const [activeCaptionClip, setActiveCaptionClip] = useState(null);
  const [copiedPlatform, setCopiedPlatform] = useState(null);

  const suggestions = CLIP_SUGGESTIONS[activeStreamer.name] || CLIP_SUGGESTIONS["default"];

  const handleGenerate = async (clip) => {
    setGeneratingId(clip.title);
    setActiveCaptionClip(clip);
    setCaptions({});

    const prompt = `You are a viral social media expert specializing in streaming clip content.

Streamer: ${activeStreamer.name}
Clip type: ${clip.type}
Clip concept: ${clip.title}
Why it works: ${clip.why}

Write 3 platform-specific captions to MAXIMIZE views. Respond in this EXACT format:

TIKTOK:
[caption with hook, 3-5 hashtags, emojis]

INSTAGRAM:
[caption with story hook, 10-15 hashtags at end]

YOUTUBE:
[SEO-optimized title-style caption, 3-5 hashtags]`;

    const result = await callClaude(prompt);
    const parsed = {};
    const tk = result.match(/TIKTOK:\n([\s\S]*?)(?=INSTAGRAM:|$)/);
    const ig = result.match(/INSTAGRAM:\n([\s\S]*?)(?=YOUTUBE:|$)/);
    const yt = result.match(/YOUTUBE:\n([\s\S]*?)$/);
    if (tk) parsed["TikTok"] = tk[1].trim();
    if (ig) parsed["Instagram Reels"] = ig[1].trim();
    if (yt) parsed["YouTube Shorts"] = yt[1].trim();

    setCaptions(parsed);
    setGeneratingId(null);
  };

  const handleDraft = (clip) => {
    const bestTime = new Date();
    bestTime.setHours(19, 30, 0, 0);
    if (bestTime < new Date()) bestTime.setDate(bestTime.getDate() + 1);

    onAddDraft({
      id: Date.now(),
      clipTitle: clip.title,
      streamer: activeStreamer.name,
      platform: activeStreamer.platform,
      viralScore: clip.viralScore,
      postAt: bestTime.toISOString(),
      captions: activeCaptionClip?.title === clip.title ? captions : null,
      where: clip.where,
    });
  };

  const handleCopy = (text, plat) => {
    navigator.clipboard.writeText(text);
    setCopiedPlatform(plat);
    setTimeout(() => setCopiedPlatform(null), 2000);
  };

  const isDrafted = (clip) => drafts.some(d => d.clipTitle === clip.title);

  return (
    <div style={{ display: "flex", height: "100%", overflow: "hidden" }}>
      {/* Left: streamer selector + clips */}
      <div style={{ width: "50%", minWidth: 300, overflowY: "auto", borderRight: "1px solid #1A1A30", padding: 18 }}>
        <div style={{ marginBottom: 14 }}>
          <div style={{ color: "#E0E0FF", fontWeight: 700, fontSize: 15, marginBottom: 4 }}>🎬 Suggested Clips to Find</div>
          <div style={{ color: "#404070", fontSize: 12, marginBottom: 12 }}>AI-generated clip ideas ranked by viral potential. Find these on their page — they're proven formats.</div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {streamerList.map(s => (
              <button key={s.name} onClick={() => { setActiveStreamer(s); setActiveCaptionClip(null); setCaptions({}); }} style={{
                background: activeStreamer.name === s.name ? "#7C3AED" : "#12121E",
                color: activeStreamer.name === s.name ? "#fff" : "#5050A0",
                border: `1px solid ${activeStreamer.name === s.name ? "#7C3AED" : "#2A2A4A"}`,
                borderRadius: 8, padding: "5px 11px", fontSize: 12, fontWeight: 600, cursor: "pointer",
              }}>
                {s.name === "DeentheGreat" ? "⭐ " : ""}{s.name}
              </button>
            ))}
          </div>
        </div>

        {/* Streamer stats bar */}
        <div style={{ background: "#12121E", border: "1px solid #2A2A4A", borderRadius: 12, padding: "12px 14px", marginBottom: 14, display: "flex", gap: 14, flexWrap: "wrap" }}>
          <div>
            <div style={{ color: "#7C3AED", fontSize: 16, fontWeight: 800 }}>{activeStreamer.followerCount}</div>
            <div style={{ color: "#404070", fontSize: 10 }}>FOLLOWERS</div>
          </div>
          <div>
            <div style={{ color: "#00C853", fontSize: 16, fontWeight: 800 }}>{activeStreamer.trend}</div>
            <div style={{ color: "#404070", fontSize: 10 }}>GROWTH</div>
          </div>
          <div>
            <div style={{ color: "#FF8C00", fontSize: 16, fontWeight: 800 }}>{activeStreamer.avgViewers}</div>
            <div style={{ color: "#404070", fontSize: 10 }}>AVG VIEWERS</div>
          </div>
          <div style={{ flex: 1, minWidth: 100 }}>
            <a href={activeStreamer.kickUrl} target="_blank" rel="noreferrer" style={{
              display: "block", background: "#1A1A3E", color: "#7C3AED", border: "1px solid #7C3AED44",
              borderRadius: 8, padding: "6px 10px", fontSize: 11, fontWeight: 700, textDecoration: "none", textAlign: "center",
            }}>
              🔗 Open Clips Page
            </a>
          </div>
        </div>

        {suggestions.map((clip, i) => (
          <ClipSuggestionCard
            key={i}
            clip={clip}
            onDraft={handleDraft}
            onGenerate={handleGenerate}
            isDrafted={isDrafted(clip)}
            isGenerating={generatingId === clip.title}
          />
        ))}
      </div>

      {/* Right: generated captions */}
      <div style={{ flex: 1, overflowY: "auto", padding: 20 }}>
        {activeCaptionClip ? (
          <>
            <div style={{ marginBottom: 16 }}>
              <div style={{ color: "#7C3AED", fontSize: 11, fontWeight: 700, marginBottom: 4 }}>CAPTIONS FOR</div>
              <div style={{ color: "#E0E0FF", fontWeight: 800, fontSize: 18 }}>{activeCaptionClip.title}</div>
              <div style={{ color: "#5050A0", fontSize: 12 }}>{activeStreamer.name} · {activeStreamer.platform}</div>
            </div>

            {generatingId === activeCaptionClip.title ? (
              <div style={{ textAlign: "center", padding: "50px 20px" }}>
                <div style={{ fontSize: 36, marginBottom: 12 }}>⚡</div>
                <div style={{ color: "#7C3AED", fontWeight: 700 }}>Writing platform captions...</div>
              </div>
            ) : Object.keys(captions).length > 0 ? (
              <>
                <div style={{ color: "#5050A0", fontSize: 10, fontWeight: 700, marginBottom: 10 }}>READY-TO-POST CAPTIONS</div>
                {PLATFORMS.map(p => captions[p] && (
                  <CaptionCard key={p} platform={p} caption={captions[p]} onCopy={handleCopy} copied={copiedPlatform} />
                ))}
                <button onClick={() => handleDraft(activeCaptionClip)} style={{
                  width: "100%", marginTop: 10,
                  background: isDrafted(activeCaptionClip) ? "#0D1A0D" : "linear-gradient(135deg, #00C853, #00A044)",
                  color: "#fff", border: "none", borderRadius: 10, padding: "12px", fontWeight: 800, fontSize: 14, cursor: "pointer",
                }}>
                  {isDrafted(activeCaptionClip) ? "✓ Already in Draft Queue" : "📋 Save to Draft Queue with Reminder"}
                </button>
                <div style={{ background: "#0D1A0D", border: "1px solid #00C85320", borderRadius: 10, padding: "12px 14px", marginTop: 12 }}>
                  <div style={{ color: "#00C853", fontSize: 10, fontWeight: 700, marginBottom: 4 }}>✅ NEXT STEPS</div>
                  <div style={{ color: "#509050", fontSize: 12, lineHeight: 1.7 }}>
                    1. Go to: {activeCaptionClip.where}<br />
                    2. Download the clip<br />
                    3. Trim to 15–45 seconds in CapCut<br />
                    4. Post at 7–9pm with caption above
                  </div>
                </div>
              </>
            ) : (
              <div style={{ textAlign: "center", padding: "50px 20px", color: "#252540" }}>
                <div style={{ fontSize: 36, marginBottom: 10 }}>✨</div>
                <div>Click "Generate Captions" on a clip suggestion</div>
              </div>
            )}
          </>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", color: "#252540", textAlign: "center" }}>
            <div style={{ fontSize: 52, marginBottom: 16 }}>🎬</div>
            <div style={{ fontSize: 16, color: "#404060", marginBottom: 8 }}>Pick a clip suggestion</div>
            <div style={{ fontSize: 13, maxWidth: 260 }}>Click "Generate Captions" on any clip idea to see platform-ready captions instantly</div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Draft Queue Tab ──────────────────────────────────────────────────
function DraftQueue({ drafts, onRemove }) {
  const ready = drafts.filter(d => new Date(d.postAt) <= new Date());
  const upcoming = drafts.filter(d => new Date(d.postAt) > new Date());

  if (drafts.length === 0) return (
    <div style={{ maxWidth: 600, margin: "60px auto", textAlign: "center", color: "#252540", padding: 20 }}>
      <div style={{ fontSize: 52, marginBottom: 14 }}>📋</div>
      <div style={{ fontSize: 18, color: "#404060", marginBottom: 8 }}>Draft queue is empty</div>
      <div style={{ fontSize: 13 }}>Go to Clip Suggestions → generate captions → save to draft queue</div>
    </div>
  );

  return (
    <div style={{ maxWidth: 700, margin: "0 auto", padding: 20 }}>
      {ready.length > 0 && (
        <>
          <div style={{ color: "#00C853", fontWeight: 800, fontSize: 14, marginBottom: 10 }}>🟢 POST NOW ({ready.length})</div>
          {ready.map(d => <DraftItem key={d.id} draft={d} onRemove={onRemove} />)}
          <div style={{ marginBottom: 20 }} />
        </>
      )}
      {upcoming.length > 0 && (
        <>
          <div style={{ color: "#FF8C00", fontWeight: 800, fontSize: 14, marginBottom: 10 }}>⏰ SCHEDULED ({upcoming.length})</div>
          {upcoming.map(d => <DraftItem key={d.id} draft={d} onRemove={onRemove} />)}
        </>
      )}
    </div>
  );
}

// ─── Revenue Estimator ────────────────────────────────────────────────
function RevenueEstimator() {
  const [pages, setPages] = useState(1);
  const [postsPerDay, setPostsPerDay] = useState(3);
  const [avgViews, setAvgViews] = useState(50000);
  const [niche, setNiche] = useState("IRL/Funny");

  const CPM = { "IRL/Funny": 2.5, "Gaming": 3.5, "Boxing/Sports": 4.0, "Celebrity": 3.0 };
  const cpm = CPM[niche] || 3;

  const monthlyViews = pages * postsPerDay * 30 * avgViews;
  const ytRevenue = (monthlyViews / 1000) * cpm * 0.4;
  const sponsorRevenue = pages * postsPerDay * 30 * (avgViews > 100000 ? 150 : avgViews > 50000 ? 60 : 20);
  const total = ytRevenue + sponsorRevenue;

  const fmt = (n) => n >= 1000000 ? `$${(n/1000000).toFixed(1)}M` : n >= 1000 ? `$${(n/1000).toFixed(0)}K` : `$${n.toFixed(0)}`;
  const fmtViews = (n) => n >= 1000000 ? `${(n/1000000).toFixed(1)}M` : n >= 1000 ? `${(n/1000).toFixed(0)}K` : n;

  return (
    <div style={{ maxWidth: 700, margin: "0 auto", padding: 20 }}>
      <h2 style={{ color: "#E0E0FF", margin: "0 0 6px" }}>💰 Revenue Estimator</h2>
      <p style={{ color: "#5050A0", fontSize: 13, margin: "0 0 20px" }}>Project your monthly earnings as you scale.</p>

      <div style={{ background: "#12121E", border: "1px solid #2A2A4A", borderRadius: 14, padding: 20, marginBottom: 16 }}>
        {[
          { label: "Number of pages", value: pages, setter: setPages, min: 1, max: 20 },
          { label: "Posts per day per page", value: postsPerDay, setter: setPostsPerDay, min: 1, max: 10 },
        ].map(({ label, value, setter, min, max }) => (
          <div key={label} style={{ marginBottom: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
              <span style={{ color: "#9090C0", fontSize: 13 }}>{label}</span>
              <span style={{ color: "#7C3AED", fontWeight: 800, fontSize: 15 }}>{value}</span>
            </div>
            <input type="range" min={min} max={max} value={value} onChange={e => setter(+e.target.value)}
              style={{ width: "100%", accentColor: "#7C3AED" }} />
          </div>
        ))}

        <div style={{ marginBottom: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
            <span style={{ color: "#9090C0", fontSize: 13 }}>Avg views per clip</span>
            <span style={{ color: "#7C3AED", fontWeight: 800, fontSize: 15 }}>{fmtViews(avgViews)}</span>
          </div>
          <input type="range" min={1000} max={500000} step={1000} value={avgViews} onChange={e => setAvgViews(+e.target.value)}
            style={{ width: "100%", accentColor: "#7C3AED" }} />
        </div>

        <div>
          <div style={{ color: "#5050A0", fontSize: 11, fontWeight: 700, marginBottom: 6 }}>CONTENT NICHE</div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {Object.keys(CPM).map(n => (
              <button key={n} onClick={() => setNiche(n)} style={{
                background: niche === n ? "#7C3AED" : "#1A1A2E",
                color: niche === n ? "#fff" : "#5050A0",
                border: `1px solid ${niche === n ? "#7C3AED" : "#2A2A4A"}`,
                borderRadius: 8, padding: "6px 12px", fontSize: 12, fontWeight: 600, cursor: "pointer",
              }}>{n}</button>
            ))}
          </div>
        </div>
      </div>

      {/* Results */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 14 }}>
        {[
          { label: "Monthly Views", value: fmtViews(monthlyViews), color: "#7C3AED" },
          { label: "YouTube/Shorts Rev", value: fmt(ytRevenue), color: "#FF8C00" },
          { label: "Sponsor Revenue", value: fmt(sponsorRevenue), color: "#00C853" },
        ].map(({ label, value, color }) => (
          <div key={label} style={{ background: "#12121E", border: "1px solid #2A2A4A", borderRadius: 12, padding: "14px", textAlign: "center" }}>
            <div style={{ color, fontSize: 22, fontWeight: 900 }}>{value}</div>
            <div style={{ color: "#404070", fontSize: 11, marginTop: 4 }}>{label}</div>
          </div>
        ))}
      </div>

      <div style={{ background: "linear-gradient(135deg, #1A0A3E, #0A1A3E)", border: "1px solid #7C3AED44", borderRadius: 14, padding: 20, textAlign: "center" }}>
        <div style={{ color: "#9090C0", fontSize: 13, marginBottom: 6 }}>ESTIMATED MONTHLY EARNINGS</div>
        <div style={{ color: "#E0E0FF", fontSize: 42, fontWeight: 900 }}>{fmt(total)}</div>
        <div style={{ color: "#5050A0", fontSize: 12, marginTop: 6 }}>
          {pages} page{pages > 1 ? "s" : ""} · {postsPerDay * pages} posts/day · {fmtViews(monthlyViews)} monthly views
        </div>
      </div>

      <div style={{ background: "#0D0D1A", border: "1px solid #2A2A4A", borderRadius: 12, padding: "14px 16px", marginTop: 14 }}>
        <div style={{ color: "#5050A0", fontSize: 10, fontWeight: 700, marginBottom: 6 }}>📈 SCALING ROADMAP</div>
        {[
          { stage: "Month 1", action: "1 page (DeentheGreat), 3 posts/day", est: "$200–500" },
          { stage: "Month 2", action: "Add 2nd page (xQc or Speed)", est: "$500–1,500" },
          { stage: "Month 3–4", action: "5 pages, systemized workflow", est: "$2,000–5,000" },
          { stage: "Month 6+", action: "10 pages, VA handles posting", est: "$5,000–15,000+" },
        ].map(({ stage, action, est }) => (
          <div key={stage} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: "1px solid #1A1A2A" }}>
            <div>
              <div style={{ color: "#7C3AED", fontSize: 12, fontWeight: 700 }}>{stage}</div>
              <div style={{ color: "#606080", fontSize: 11 }}>{action}</div>
            </div>
            <div style={{ color: "#00C853", fontWeight: 800, fontSize: 13 }}>{est}/mo</div>
          </div>
        ))}
      </div>
    </div>
  );
}


// ─── DAILY WORKFLOW SYSTEM ────────────────────────────────────────────

const TODAY_KEY = "clipprofit_today_" + new Date().toDateString();

async function generateDailyBriefing(streamers) {
  const top = (streamers || STREAMERS).slice(0, 3).map(s => s.name).join(", ");
  const prompt = `You are a clip page manager. Generate a daily posting plan for today.

Top streamers to focus on: ${top}
Today's date: ${new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}

Give me exactly 3 specific clip missions for today. Each should tell me exactly what to look for.

Respond ONLY in JSON, no extra text:
{
  "greeting": "<motivational one-liner for today>",
  "missions": [
    {
      "id": 1,
      "streamer": "<name>",
      "platform": "<Kick|Twitch|YouTube>",
      "clipUrl": "<their clips page URL>",
      "mission": "<exactly what clip to find in one sentence>",
      "why": "<why this will perform well today in one sentence>",
      "estimatedViews": "<e.g. 200K-800K>",
      "bestPostTime": "<e.g. 7pm EST>",
      "bestPlatform": "<TikTok|Instagram Reels|YouTube Shorts>",
      "viralScore": <number 0-100>
    }
  ]
}`;
  const raw = await callClaude(prompt, 1000);
  return JSON.parse(raw.replace(/\`\`\`json|\`\`\`/g, "").trim());
}

function MissionCard({ mission, index, done, onToggle, onGenerate, isGenerating, captions, copied, onCopy }) {
  const [expanded, setExpanded] = useState(false);
  const scoreColor = mission.viralScore >= 85 ? "#FF4444" : mission.viralScore >= 70 ? "#FF8C00" : "#00C853";

  return (
    <div style={{
      background: done ? "#0D1A0D" : "#12121E",
      border: \`1px solid \${done ? "#00C85340" : "#1E1E3A"}\`,
      borderRadius: 14, padding: 16, marginBottom: 12,
      opacity: done ? 0.75 : 1,
    }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
        <button onClick={() => onToggle(mission.id)} style={{
          width: 28, height: 28, borderRadius: "50%", flexShrink: 0, marginTop: 2,
          background: done ? "#00C853" : "transparent",
          border: \`2px solid \${done ? "#00C853" : "#3A3A6A"}\`,
          cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
          color: "#fff", fontSize: 14,
        }}>{done ? "✓" : index + 1}</button>

        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <div style={{ color: "#fff", fontWeight: 800, fontSize: 15 }}>{mission.streamer}</div>
              <div style={{ color: "#5050A0", fontSize: 11, marginTop: 2 }}>{mission.platform} · Best on {mission.bestPlatform}</div>
            </div>
            <div style={{ background: scoreColor + "22", color: scoreColor, border: \`1px solid \${scoreColor}44\`, borderRadius: 6, padding: "3px 8px", fontSize: 12, fontWeight: 800 }}>
              🔥 {mission.viralScore}
            </div>
          </div>

          <div style={{ background: "#0A0A18", borderRadius: 8, padding: "10px 12px", margin: "10px 0" }}>
            <div style={{ color: "#5050A0", fontSize: 10, fontWeight: 700, marginBottom: 3 }}>🎯 TODAY'S MISSION</div>
            <div style={{ color: "#C0C0E0", fontSize: 13, lineHeight: 1.5 }}>{mission.mission}</div>
          </div>

          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
            <span style={{ color: "#00C853", fontSize: 12 }}>📈 {mission.estimatedViews} est. views</span>
            <span style={{ color: "#FF8C00", fontSize: 12 }}>⏰ Post at {mission.bestPostTime}</span>
          </div>

          <div style={{ display: "flex", gap: 8 }}>
            <a href={mission.clipUrl} target="_blank" rel="noreferrer" style={{
              flex: 1, background: "#1A1A3E", color: "#7C3AED", border: "1px solid #7C3AED44",
              borderRadius: 8, padding: "8px", fontSize: 12, fontWeight: 700,
              textDecoration: "none", textAlign: "center",
            }}>🔗 Find Clip</a>
            <button onClick={() => { onGenerate(mission); setExpanded(true); }} disabled={isGenerating} style={{
              flex: 1, background: isGenerating ? "#1A1A3E" : "linear-gradient(135deg, #7C3AED, #4F46E5)",
              color: "#fff", border: "none", borderRadius: 8, padding: "8px",
              fontSize: 12, fontWeight: 700, cursor: isGenerating ? "not-allowed" : "pointer",
            }}>{isGenerating ? "⚡ Writing..." : "✨ Get Captions"}</button>
          </div>
        </div>
      </div>

      {/* Captions */}
      {expanded && captions && Object.keys(captions).length > 0 && (
        <div style={{ marginTop: 14 }}>
          <div style={{ color: "#5050A0", fontSize: 10, fontWeight: 700, marginBottom: 8 }}>READY-TO-POST CAPTIONS</div>
          {PLATFORMS.map(p => captions[p] && (
            <CaptionCard key={p} platform={p} caption={captions[p]} onCopy={onCopy} copied={copied} />
          ))}
          <button onClick={() => onToggle(mission.id)} style={{
            width: "100%", marginTop: 8,
            background: "linear-gradient(135deg, #00C853, #00A044)",
            color: "#fff", border: "none", borderRadius: 10, padding: "11px",
            fontWeight: 800, fontSize: 14, cursor: "pointer",
          }}>✅ Mark as Posted</button>
        </div>
      )}

      {expanded && (!captions || Object.keys(captions).length === 0) && !isGenerating && (
        <div style={{ marginTop: 10, color: "#303060", fontSize: 13, textAlign: "center" }}>
          Tap "Get Captions" to generate platform captions
        </div>
      )}

      {!expanded && captions && Object.keys(captions).length > 0 && (
        <button onClick={() => setExpanded(true)} style={{
          width: "100%", marginTop: 10, background: "#1A1A2E", color: "#7C3AED",
          border: "1px solid #2A2A4A", borderRadius: 8, padding: "7px",
          fontSize: 12, fontWeight: 600, cursor: "pointer",
        }}>▼ View Captions</button>
      )}
    </div>
  );
}

function DailyWorkflow({ streamers }) {
  const [briefing, setBriefing] = useState(null);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState({});
  const [generatingId, setGeneratingId] = useState(null);
  const [allCaptions, setAllCaptions] = useState({});
  const [copied, setCopied] = useState(null);

  // Auto-load on mount
  useEffect(() => {
    try {
      const cached = localStorage.getItem(TODAY_KEY);
      if (cached) { setBriefing(JSON.parse(cached)); return; }
    } catch (_) {}
    loadBriefing();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadBriefing = async () => {
    setLoading(true);
    try {
      const data = await generateDailyBriefing(streamers);
      setBriefing(data);
      localStorage.setItem(TODAY_KEY, JSON.stringify(data));
    } catch (_) {}
    setLoading(false);
  };

  const handleToggle = (id) => setDone(prev => ({ ...prev, [id]: !prev[id] }));

  const handleGenerate = async (mission) => {
    setGeneratingId(mission.id);
    const prompt = \`You are a viral social media expert for streaming clips.

Streamer: \${mission.streamer}
Mission: \${mission.mission}
Best platform: \${mission.bestPlatform}

Write 3 platform captions. Respond in EXACT format:

TIKTOK:
[caption with hook, 3-5 hashtags, emojis]

INSTAGRAM:
[caption with story hook, 10-15 hashtags]

YOUTUBE:
[SEO-optimized caption, 3-5 hashtags]\`;

    const result = await callClaude(prompt);
    const parsed = {};
    const tk = result.match(/TIKTOK:\n([\s\S]*?)(?=INSTAGRAM:|$)/);
    const ig = result.match(/INSTAGRAM:\n([\s\S]*?)(?=YOUTUBE:|$)/);
    const yt = result.match(/YOUTUBE:\n([\s\S]*?)$/);
    if (tk) parsed["TikTok"] = tk[1].trim();
    if (ig) parsed["Instagram Reels"] = ig[1].trim();
    if (yt) parsed["YouTube Shorts"] = yt[1].trim();
    setAllCaptions(prev => ({ ...prev, [mission.id]: parsed }));
    setGeneratingId(null);
  };

  const handleCopy = (text, plat) => {
    navigator.clipboard.writeText(text);
    setCopied(plat);
    setTimeout(() => setCopied(null), 2000);
  };

  const completedCount = Object.values(done).filter(Boolean).length;
  const totalMissions = briefing?.missions?.length || 3;

  return (
    <div style={{ maxWidth: 700, margin: "0 auto", padding: 20 }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <div>
          <div style={{ color: "#7C3AED", fontSize: 11, fontWeight: 700, letterSpacing: "0.05em" }}>
            {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" }).toUpperCase()}
          </div>
          <h2 style={{ color: "#E0E0FF", margin: "4px 0 0", fontSize: 22, fontWeight: 900 }}>Today's Clip Missions</h2>
        </div>
        <button onClick={loadBriefing} disabled={loading} style={{
          background: "#12121E", color: "#5050A0", border: "1px solid #2A2A4A",
          borderRadius: 8, padding: "7px 12px", fontSize: 12, fontWeight: 600, cursor: "pointer",
        }}>{loading ? "⏳" : "🔄 New"}</button>
      </div>

      {/* Progress bar */}
      {briefing && (
        <div style={{ background: "#12121E", border: "1px solid #2A2A4A", borderRadius: 12, padding: "14px 16px", marginBottom: 18 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
            <span style={{ color: "#9090C0", fontSize: 13, fontWeight: 600 }}>Daily Progress</span>
            <span style={{ color: completedCount === totalMissions ? "#00C853" : "#7C3AED", fontWeight: 800, fontSize: 13 }}>
              {completedCount}/{totalMissions} posted
            </span>
          </div>
          <div style={{ background: "#1A1A2E", borderRadius: 99, height: 8 }}>
            <div style={{
              width: \`\${(completedCount / totalMissions) * 100}%\`,
              height: "100%", borderRadius: 99,
              background: completedCount === totalMissions ? "#00C853" : "linear-gradient(90deg, #7C3AED, #4F46E5)",
              transition: "width 0.5s ease",
            }} />
          </div>
          {briefing.greeting && (
            <div style={{ color: "#5050A0", fontSize: 12, marginTop: 10, fontStyle: "italic" }}>
              "{briefing.greeting}"
            </div>
          )}
        </div>
      )}

      {loading && (
        <div style={{ textAlign: "center", padding: "60px 20px" }}>
          <div style={{ fontSize: 40, marginBottom: 14 }}>⚡</div>
          <div style={{ color: "#7C3AED", fontWeight: 700, fontSize: 16 }}>Building your daily clip plan...</div>
          <div style={{ color: "#404070", fontSize: 13, marginTop: 8 }}>AI is researching what to post today</div>
        </div>
      )}

      {!loading && briefing?.missions?.map((m, i) => (
        <MissionCard
          key={m.id}
          mission={m}
          index={i}
          done={!!done[m.id]}
          onToggle={handleToggle}
          onGenerate={handleGenerate}
          isGenerating={generatingId === m.id}
          captions={allCaptions[m.id]}
          copied={copied}
          onCopy={handleCopy}
        />
      ))}

      {!loading && !briefing && (
        <div style={{ textAlign: "center", padding: "60px 20px", color: "#252540" }}>
          <div style={{ fontSize: 52, marginBottom: 14 }}>📋</div>
          <div style={{ fontSize: 16, color: "#404060", marginBottom: 16 }}>No briefing generated yet</div>
          <button onClick={loadBriefing} style={{
            background: "linear-gradient(135deg, #7C3AED, #4F46E5)", color: "#fff",
            border: "none", borderRadius: 10, padding: "13px 28px", fontWeight: 800, fontSize: 15, cursor: "pointer",
          }}>⚡ Generate Today's Missions</button>
        </div>
      )}

      {completedCount === totalMissions && briefing && (
        <div style={{ background: "linear-gradient(135deg, #0D1A0D, #0A2A0A)", border: "1px solid #00C85340", borderRadius: 14, padding: 20, textAlign: "center", marginTop: 8 }}>
          <div style={{ fontSize: 36, marginBottom: 8 }}>🏆</div>
          <div style={{ color: "#00C853", fontWeight: 900, fontSize: 18, marginBottom: 6 }}>All missions complete!</div>
          <div style={{ color: "#509050", fontSize: 13 }}>You've posted all {totalMissions} clips today. Come back tomorrow for new missions.</div>
        </div>
      )}
    </div>
  );
}


// ─── SMART SCHEDULE + STANDOUT SYSTEM ────────────────────────────────

const PRIME_WINDOWS_EST = {
  Sunday:    [{ time: "11:00", label: "11am", platform: "TikTok" }, { time: "19:00", label: "7pm", platform: "All" }],
  Monday:    [{ time: "09:00", label: "9am",  platform: "YouTube Shorts" }, { time: "12:00", label: "12pm", platform: "TikTok" }, { time: "19:00", label: "7pm", platform: "All" }],
  Tuesday:   [{ time: "09:00", label: "9am",  platform: "YouTube Shorts" }, { time: "12:00", label: "12pm", platform: "TikTok" }, { time: "19:00", label: "7pm", platform: "All" }],
  Wednesday: [{ time: "09:00", label: "9am",  platform: "TikTok" }, { time: "14:00", label: "2pm", platform: "Instagram Reels" }, { time: "19:00", label: "7pm", platform: "All" }],
  Thursday:  [{ time: "12:00", label: "12pm", platform: "TikTok" }, { time: "19:00", label: "7pm", platform: "All" }, { time: "21:00", label: "9pm", platform: "Instagram Reels" }],
  Friday:    [{ time: "12:00", label: "12pm", platform: "All" }, { time: "19:00", label: "7pm", platform: "All" }, { time: "21:00", label: "9pm", platform: "TikTok" }],
  Saturday:  [{ time: "11:00", label: "11am", platform: "All" }, { time: "19:00", label: "7pm", platform: "All" }, { time: "21:00", label: "9pm", platform: "TikTok" }],
};

const POST_ORDER = ["TikTok", "YouTube Shorts", "Instagram Reels"];

function getNextWindows() {
  const now = new Date();
  const day = now.toLocaleDateString("en-US", { weekday: "long", timeZone: "America/New_York" });
  const windows = PRIME_WINDOWS_EST[day] || PRIME_WINDOWS_EST["Monday"];
  const nowEST = new Date(now.toLocaleString("en-US", { timeZone: "America/New_York" }));
  const currentMins = nowEST.getHours() * 60 + nowEST.getMinutes();

  return windows.map(w => {
    const [h, m] = w.time.split(":").map(Number);
    const windowMins = h * 60 + m;
    const diff = windowMins - currentMins;
    const isPast = diff < -30;
    const isNow = diff >= -30 && diff <= 15;
    const minsUntil = diff;
    const hoursUntil = Math.floor(Math.abs(diff) / 60);
    const minsRem = Math.abs(diff) % 60;
    const label = isPast ? "passed" : isNow ? "🔴 POST NOW" : `in ${hoursUntil > 0 ? hoursUntil + "h " : ""}${minsRem}m`;
    return { ...w, isPast, isNow, label, minsUntil };
  }).sort((a, b) => a.minsUntil - b.minsUntil);
}

async function generateStandoutHooks(streamer, clipDesc, platform) {
  const prompt = `You are a viral content strategist who specializes in making streaming clips stand out above ALL competing clip pages.

Streamer: ${streamer}
Clip: ${clipDesc}
Primary platform: ${platform}

Generate 5 scroll-stopping hooks + standout strategies. Respond ONLY in JSON:
{
  "hooks": [
    { "text": "<hook line under 10 words>", "why": "<why this stops the scroll>" }
  ],
  "thumbnailText": "<bold text to overlay on thumbnail, max 5 words>",
  "thumbnailStrategy": "<what visual style to use on the thumbnail>",
  "competitorGap": "<what other clip pages are NOT doing that you should>",
  "uniqueAngle": "<the specific angle that makes YOUR version of this clip different>",
  "firstCommentIdea": "<what to post as your first comment to boost engagement>"
}`;
  const raw = await callClaude(prompt, 1000);
  return JSON.parse(raw.replace(/\`\`\`json|\`\`\`/g, "").trim());
}

async function generateWeeklySchedule(streamers) {
  const names = (streamers || STREAMERS).slice(0, 4).map(s => s.name).join(", ");
  const prompt = `You are a clip page scheduling expert for EST timezone.

Streamers available: ${names}
Goal: Maximum viral reach on TikTok, YouTube Shorts, Instagram Reels

Create a full 7-day posting schedule. Each day has 3 posts.
Respond ONLY in JSON:
{
  "week": [
    {
      "day": "Monday",
      "posts": [
        {
          "time": "9:00am EST",
          "platform": "YouTube Shorts",
          "streamer": "<name>",
          "clipType": "<what to clip>",
          "reason": "<why this time + platform combo>",
          "priority": <1-3, 1 being highest>
        }
      ]
    }
  ]
}`;
  const raw = await callClaude(prompt, 1500);
  return JSON.parse(raw.replace(/\`\`\`json|\`\`\`/g, "").trim());
}

// ─── Schedule Tab ─────────────────────────────────────────────────────
function SmartSchedule({ streamers }) {
  const [windows, setWindows] = useState(getNextWindows());
  const [weekSchedule, setWeekSchedule] = useState(null);
  const [scheduleLoading, setScheduleLoading] = useState(false);
  const [standout, setStandout] = useState(null);
  const [standoutLoading, setStandoutLoading] = useState(false);
  const [clipDesc, setClipDesc] = useState("");
  const [streamer, setStreamer] = useState((streamers && streamers[0]?.name) || "DeentheGreat");
  const [platform, setPlatform] = useState("TikTok");
  const [activeSection, setActiveSection] = useState("schedule");
  const [notifSet, setNotifSet] = useState({});

  // Refresh windows every minute
  useEffect(() => {
    const timer = setInterval(() => setWindows(getNextWindows()), 60000);
    return () => clearInterval(timer);
  }, []);

  const scheduleNotif = (w) => {
    if (!("Notification" in window) || Notification.permission !== "granted") {
      alert("Enable notifications first (tap the bell icon at the top)");
      return;
    }
    const now = new Date();
    const estNow = new Date(now.toLocaleString("en-US", { timeZone: "America/New_York" }));
    const [h, m] = w.time.split(":").map(Number);
    const target = new Date(estNow);
    target.setHours(h, m, 0, 0);
    if (target <= estNow) target.setDate(target.getDate() + 1);
    const delay = target - estNow;
    setTimeout(() => {
      new Notification(`⏰ Prime posting window: ${w.label} EST`, {
        body: `Post on ${w.platform} NOW for maximum reach! Open ClipProfitAI.`,
        icon: "/icon-192.png",
      });
    }, delay);
    setNotifSet(prev => ({ ...prev, [w.time]: true }));
  };

  const loadWeekSchedule = async () => {
    setScheduleLoading(true);
    try {
      const data = await generateWeeklySchedule(streamers);
      setWeekSchedule(data);
    } catch (_) {}
    setScheduleLoading(false);
  };

  const loadStandout = async () => {
    if (!clipDesc.trim()) return;
    setStandoutLoading(true);
    try {
      const data = await generateStandoutHooks(streamer, clipDesc, platform);
      setStandout(data);
    } catch (_) {}
    setStandoutLoading(false);
  };

  const dayColors = { Monday: "#7C3AED", Tuesday: "#4F46E5", Wednesday: "#2563EB", Thursday: "#0891B2", Friday: "#059669", Saturday: "#D97706", Sunday: "#DC2626" };
  const today = new Date().toLocaleDateString("en-US", { weekday: "long" });

  return (
    <div style={{ maxWidth: 760, margin: "0 auto", padding: 20 }}>
      {/* Section toggle */}
      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {[
          { id: "schedule", label: "📅 Prime Times" },
          { id: "week",     label: "🗓️ Weekly Plan"  },
          { id: "standout", label: "🌟 Stand Out"    },
        ].map(s => (
          <button key={s.id} onClick={() => setActiveSection(s.id)} style={{
            flex: 1, background: activeSection === s.id ? "#7C3AED" : "#12121E",
            color: activeSection === s.id ? "#fff" : "#5050A0",
            border: `1px solid ${activeSection === s.id ? "#7C3AED" : "#2A2A4A"}`,
            borderRadius: 10, padding: "10px 8px", fontWeight: 700, fontSize: 13, cursor: "pointer",
          }}>{s.label}</button>
        ))}
      </div>

      {/* ── Prime Times ── */}
      {activeSection === "schedule" && (
        <>
          <div style={{ marginBottom: 16 }}>
            <h2 style={{ color: "#E0E0FF", margin: "0 0 4px", fontSize: 20, fontWeight: 900 }}>Today's Prime Windows</h2>
            <div style={{ color: "#5050A0", fontSize: 13 }}>
              {today} · All times EST · Tap the bell to get notified
            </div>
          </div>

          {windows.map((w, i) => (
            <div key={i} style={{
              background: w.isNow ? "#1A0A3E" : w.isPast ? "#0D0D0D" : "#12121E",
              border: `1px solid ${w.isNow ? "#7C3AED" : w.isPast ? "#1A1A1A" : "#1E1E3A"}`,
              borderRadius: 14, padding: "16px 18px", marginBottom: 12,
              boxShadow: w.isNow ? "0 0 20px #7C3AED33" : "none",
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
                    <div style={{ color: w.isNow ? "#fff" : w.isPast ? "#333" : "#E0E0FF", fontWeight: 900, fontSize: 22, fontFamily: "monospace" }}>
                      {w.label} EST
                    </div>
                    {w.isNow && (
                      <span style={{ background: "#FF444422", color: "#FF4444", border: "1px solid #FF444444", borderRadius: 6, padding: "2px 8px", fontSize: 11, fontWeight: 800 }}>
                        🔴 LIVE NOW
                      </span>
                    )}
                  </div>
                  <div style={{ color: w.isPast ? "#333" : "#5050A0", fontSize: 12 }}>
                    Best for: <span style={{ color: w.isPast ? "#333" : "#7C3AED", fontWeight: 700 }}>{w.platform}</span>
                  </div>
                  <div style={{ color: w.isPast ? "#252525" : "#404070", fontSize: 12, marginTop: 3 }}>
                    {w.isPast ? "Window passed" : w.isNow ? "Post immediately for max reach" : `Opens ${w.label}`}
                  </div>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 8, alignItems: "flex-end" }}>
                  {!w.isPast && (
                    <button onClick={() => scheduleNotif(w)} style={{
                      background: notifSet[w.time] ? "#0D1A0D" : "#1A1A3E",
                      color: notifSet[w.time] ? "#00C853" : "#7C3AED",
                      border: `1px solid ${notifSet[w.time] ? "#00C85340" : "#7C3AED44"}`,
                      borderRadius: 8, padding: "8px 12px", fontSize: 13, fontWeight: 700, cursor: "pointer",
                    }}>
                      {notifSet[w.time] ? "✓ Set" : "🔔 Notify Me"}
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}

          {/* Posting order guide */}
          <div style={{ background: "#12121E", border: "1px solid #2A2A4A", borderRadius: 14, padding: 18, marginTop: 8 }}>
            <div style={{ color: "#5050A0", fontSize: 11, fontWeight: 700, marginBottom: 12, letterSpacing: "0.05em" }}>
              📋 RECOMMENDED POSTING ORDER
            </div>
            {POST_ORDER.map((p, i) => (
              <div key={p} style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: i < POST_ORDER.length - 1 ? 12 : 0 }}>
                <div style={{ width: 28, height: 28, borderRadius: "50%", background: "#7C3AED", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: 13, flexShrink: 0 }}>{i + 1}</div>
                <div>
                  <div style={{ color: "#E0E0FF", fontWeight: 700, fontSize: 14 }}>{p}</div>
                  <div style={{ color: "#5050A0", fontSize: 12 }}>
                    {i === 0 ? "Post first — largest reach, fastest virality signal" : i === 1 ? "Post 30 min later — drives long-term search discovery" : "Post last — repurposes momentum from TikTok"}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {/* ── Weekly Plan ── */}
      {activeSection === "week" && (
        <>
          <div style={{ marginBottom: 16 }}>
            <h2 style={{ color: "#E0E0FF", margin: "0 0 4px", fontSize: 20, fontWeight: 900 }}>7-Day Posting Schedule</h2>
            <p style={{ color: "#5050A0", fontSize: 13, margin: 0 }}>AI-generated weekly plan optimized for EST prime times.</p>
          </div>
          <button onClick={loadWeekSchedule} disabled={scheduleLoading} style={{
            width: "100%", marginBottom: 18,
            background: scheduleLoading ? "#1A1A3E" : "linear-gradient(135deg, #7C3AED, #4F46E5)",
            color: "#fff", border: "none", borderRadius: 10, padding: "13px",
            fontWeight: 800, fontSize: 14, cursor: scheduleLoading ? "not-allowed" : "pointer",
          }}>{scheduleLoading ? "⚡ Building your week..." : "🗓️ Generate This Week's Plan"}</button>

          {weekSchedule?.week?.map(day => (
            <div key={day.day} style={{
              background: day.day === today ? "#1A1A3E" : "#12121E",
              border: `1px solid ${day.day === today ? "#7C3AED" : "#1E1E3A"}`,
              borderRadius: 14, padding: 16, marginBottom: 12,
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
                <div style={{ width: 10, height: 10, borderRadius: "50%", background: dayColors[day.day] || "#7C3AED" }} />
                <div style={{ color: day.day === today ? "#fff" : "#9090C0", fontWeight: 800, fontSize: 15 }}>
                  {day.day} {day.day === today && <span style={{ color: "#7C3AED", fontSize: 12 }}>← TODAY</span>}
                </div>
              </div>
              {day.posts?.map((post, i) => (
                <div key={i} style={{ display: "flex", gap: 10, marginBottom: i < day.posts.length - 1 ? 10 : 0, paddingBottom: i < day.posts.length - 1 ? 10 : 0, borderBottom: i < day.posts.length - 1 ? "1px solid #1A1A2A" : "none" }}>
                  <div style={{ width: 4, borderRadius: 99, background: post.priority === 1 ? "#FF4444" : post.priority === 2 ? "#FF8C00" : "#00C853", flexShrink: 0 }} />
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                      <span style={{ color: "#7C3AED", fontWeight: 700, fontSize: 13 }}>{post.time}</span>
                      <span style={{ color: "#5050A0", fontSize: 12 }}>{post.platform}</span>
                    </div>
                    <div style={{ color: "#C0C0E0", fontSize: 13, marginTop: 2 }}>{post.streamer} — {post.clipType}</div>
                    <div style={{ color: "#404060", fontSize: 11, marginTop: 2 }}>{post.reason}</div>
                  </div>
                </div>
              ))}
            </div>
          ))}

          {!weekSchedule && !scheduleLoading && (
            <div style={{ textAlign: "center", padding: "40px 20px", color: "#252540" }}>
              <div style={{ fontSize: 44, marginBottom: 12 }}>🗓️</div>
              <div>Tap above to generate your optimized week</div>
            </div>
          )}
        </>
      )}

      {/* ── Stand Out ── */}
      {activeSection === "standout" && (
        <>
          <div style={{ marginBottom: 16 }}>
            <h2 style={{ color: "#E0E0FF", margin: "0 0 4px", fontSize: 20, fontWeight: 900 }}>🌟 Stand Out Engine</h2>
            <p style={{ color: "#5050A0", fontSize: 13, margin: 0 }}>AI finds the gap other clip pages miss and makes your version the one that pops.</p>
          </div>

          <div style={{ background: "#12121E", border: "1px solid #2A2A4A", borderRadius: 14, padding: 18, marginBottom: 16 }}>
            <label style={{ color: "#5050A0", fontSize: 11, fontWeight: 700, display: "block", marginBottom: 6 }}>STREAMER</label>
            <select value={streamer} onChange={e => setStreamer(e.target.value)} style={{
              width: "100%", background: "#0A0A12", border: "1px solid #2A2A4A", borderRadius: 8,
              padding: "9px 12px", color: "#E0E0FF", fontSize: 13, marginBottom: 12, outline: "none",
            }}>
              {(streamers || STREAMERS).map(s => <option key={s.name} value={s.name}>{s.name}</option>)}
            </select>

            <label style={{ color: "#5050A0", fontSize: 11, fontWeight: 700, display: "block", marginBottom: 6 }}>PRIMARY PLATFORM</label>
            <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
              {PLATFORMS.map(p => (
                <button key={p} onClick={() => setPlatform(p)} style={{
                  flex: 1, background: platform === p ? "#7C3AED" : "#1A1A2E",
                  color: platform === p ? "#fff" : "#5050A0",
                  border: `1px solid ${platform === p ? "#7C3AED" : "#2A2A4A"}`,
                  borderRadius: 8, padding: "7px 4px", fontSize: 11, fontWeight: 600, cursor: "pointer",
                }}>{p.replace(" Reels", "").replace(" Shorts", "")}</button>
              ))}
            </div>

            <label style={{ color: "#5050A0", fontSize: 11, fontWeight: 700, display: "block", marginBottom: 6 }}>DESCRIBE YOUR CLIP ✱</label>
            <textarea value={clipDesc} onChange={e => setClipDesc(e.target.value)} rows={3}
              placeholder="e.g. Deen reacts to someone throwing money at him during a live stream, crowd goes crazy"
              style={{ width: "100%", boxSizing: "border-box", background: "#0A0A12", border: "1px solid #2A2A4A", borderRadius: 8, padding: "9px 12px", color: "#E0E0FF", fontSize: 13, outline: "none", fontFamily: "inherit", resize: "vertical" }} />

            <button onClick={loadStandout} disabled={standoutLoading || !clipDesc.trim()} style={{
              width: "100%", marginTop: 12,
              background: standoutLoading ? "#1A1A3E" : "linear-gradient(135deg, #7C3AED, #4F46E5)",
              color: "#fff", border: "none", borderRadius: 10, padding: "12px",
              fontWeight: 800, fontSize: 14, cursor: standoutLoading || !clipDesc.trim() ? "not-allowed" : "pointer",
              opacity: !clipDesc.trim() ? 0.5 : 1,
            }}>{standoutLoading ? "⚡ Finding your edge..." : "🌟 Make My Clip Stand Out"}</button>
          </div>

          {standout && (
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {/* Hooks */}
              <div style={{ background: "#12121E", border: "1px solid #2A2A4A", borderRadius: 14, padding: 18 }}>
                <div style={{ color: "#5050A0", fontSize: 11, fontWeight: 700, marginBottom: 12 }}>🎣 SCROLL-STOPPING HOOKS (pick one)</div>
                {standout.hooks?.map((h, i) => (
                  <div key={i} style={{ background: "#0D0D1A", borderRadius: 10, padding: "12px 14px", marginBottom: 8 }}>
                    <div style={{ color: "#E0E0FF", fontWeight: 700, fontSize: 15, marginBottom: 4 }}>"{h.text}"</div>
                    <div style={{ color: "#5050A0", fontSize: 12 }}>{h.why}</div>
                  </div>
                ))}
              </div>

              {/* Thumbnail */}
              <div style={{ background: "#12121E", border: "1px solid #2A2A4A", borderRadius: 14, padding: 18 }}>
                <div style={{ color: "#5050A0", fontSize: 11, fontWeight: 700, marginBottom: 10 }}>🖼️ THUMBNAIL STRATEGY</div>
                <div style={{ background: "linear-gradient(135deg, #1A0A3E, #0A1A3E)", borderRadius: 10, padding: "16px", textAlign: "center", marginBottom: 12 }}>
                  <div style={{ color: "#fff", fontWeight: 900, fontSize: 22, letterSpacing: "-0.02em" }}>{standout.thumbnailText}</div>
                  <div style={{ color: "#7C3AED", fontSize: 11, marginTop: 6 }}>← Overlay this text on your thumbnail</div>
                </div>
                <div style={{ color: "#9090C0", fontSize: 13, lineHeight: 1.6 }}>{standout.thumbnailStrategy}</div>
              </div>

              {/* Competitor gap + unique angle */}
              <div style={{ display: "flex", gap: 10 }}>
                <div style={{ flex: 1, background: "#0D1A0D", border: "1px solid #00C85330", borderRadius: 12, padding: "14px 16px" }}>
                  <div style={{ color: "#00C853", fontSize: 10, fontWeight: 700, marginBottom: 6 }}>🎯 YOUR UNIQUE ANGLE</div>
                  <div style={{ color: "#509050", fontSize: 13, lineHeight: 1.5 }}>{standout.uniqueAngle}</div>
                </div>
                <div style={{ flex: 1, background: "#1A0A0D", border: "1px solid #FF444430", borderRadius: 12, padding: "14px 16px" }}>
                  <div style={{ color: "#FF8C00", fontSize: 10, fontWeight: 700, marginBottom: 6 }}>💡 COMPETITOR GAP</div>
                  <div style={{ color: "#905030", fontSize: 13, lineHeight: 1.5 }}>{standout.competitorGap}</div>
                </div>
              </div>

              {/* First comment */}
              <div style={{ background: "#12121E", border: "1px solid #2A2A4A", borderRadius: 14, padding: 16 }}>
                <div style={{ color: "#5050A0", fontSize: 11, fontWeight: 700, marginBottom: 6 }}>💬 FIRST COMMENT TO BOOST ENGAGEMENT</div>
                <div style={{ background: "#0A0A18", borderRadius: 8, padding: "10px 14px" }}>
                  <div style={{ color: "#C0C0E0", fontSize: 14 }}>{standout.firstCommentIdea}</div>
                </div>
                <button onClick={() => navigator.clipboard.writeText(standout.firstCommentIdea)} style={{
                  width: "100%", marginTop: 10, background: "#1A1A3E", color: "#7C3AED",
                  border: "1px solid #7C3AED44", borderRadius: 8, padding: "8px",
                  fontSize: 13, fontWeight: 700, cursor: "pointer",
                }}>Copy Comment</button>
              </div>
            </div>
          )}

          {!standout && !standoutLoading && (
            <div style={{ textAlign: "center", padding: "40px 20px", color: "#252540" }}>
              <div style={{ fontSize: 44, marginBottom: 12 }}>🌟</div>
              <div>Describe your clip above to get standout strategies</div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ─── Auto-Research System ─────────────────────────────────────────────
const CACHE_KEY = "clipprofit_streamer_cache";
const CACHE_TTL = 24 * 60 * 60 * 1000; // 24 hours

async function fetchLiveStreamers() {
  const prompt = `You are a streaming clip monetization expert. It is ${new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}.

Research and rank the TOP 6 most profitable streamers to clip RIGHT NOW for TikTok, Instagram Reels, and YouTube Shorts. Focus on Kick and Twitch streamers with high viral clip potential.

Always include DeentheGreat (Kick) as one of them since that's our primary focus.

Respond ONLY in this exact JSON format, no extra text:
{
  "updatedAt": "${new Date().toISOString()}",
  "streamers": [
    {
      "name": "streamer name",
      "category": "content category",
      "avgViewers": "e.g. 20K",
      "peakViewers": "e.g. 50K",
      "clipScore": <number 0-100>,
      "trend": "e.g. +15% this week",
      "platform": "Kick or Twitch or YouTube",
      "followerCount": "e.g. 500K",
      "monetizationNotes": "2-3 sentences on why their clips are profitable right now",
      "clipTypes": ["type1", "type2", "type3"],
      "kickUrl": "direct URL to their clips page"
    }
  ]
}`;

  const raw = await callClaude(prompt, 1500);
  const clean = raw.replace(/```json|```/g, "").trim();
  return JSON.parse(clean);
}

// ─── Main App ─────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState("today");
  const [drafts, setDrafts] = useState([]);
  const [notifGranted, setNotifGranted] = useState(false);
  const [liveStreamers, setLiveStreamers] = useState(STREAMERS);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [refreshError, setRefreshError] = useState(false);

  // Load cache or auto-fetch on mount
  useEffect(() => {
    if ("Notification" in window && Notification.permission === "granted") setNotifGranted(true);

    try {
      const cached = localStorage.getItem(CACHE_KEY);
      if (cached) {
        const parsed = JSON.parse(cached);
        const age = Date.now() - new Date(parsed.updatedAt).getTime();
        if (age < CACHE_TTL) {
          // Cache is fresh — use it
          setLiveStreamers(parsed.streamers);
          setLastUpdated(new Date(parsed.updatedAt));
          return;
        }
      }
    } catch (_) {}

    // Cache missing or stale — auto-fetch
    handleRefresh();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    setRefreshError(false);
    try {
      const data = await fetchLiveStreamers();
      if (data?.streamers?.length) {
        setLiveStreamers(data.streamers);
        setLastUpdated(new Date(data.updatedAt));
        localStorage.setItem(CACHE_KEY, JSON.stringify(data));
      }
    } catch (_) {
      setRefreshError(true);
      // Keep showing existing streamers on error
    }
    setIsRefreshing(false);
  };

  const requestNotif = async () => {
    if ("Notification" in window) {
      const perm = await Notification.requestPermission();
      if (perm === "granted") {
        setNotifGranted(true);
        new Notification("ClipProfitAI 🔥", { body: "Notifications on! We'll alert you when it's time to post." });
      }
    }
  };

  const addDraft = useCallback((draft) => {
    setDrafts(prev => {
      if (prev.some(d => d.clipTitle === draft.clipTitle)) return prev;
      const newDraft = { ...draft };
      // Schedule notification
      if (notifGranted) {
        const delay = new Date(draft.postAt) - new Date();
        if (delay > 0) setTimeout(() => {
          new Notification(`⏰ Time to post: ${draft.clipTitle}`, { body: `Your ${draft.streamer} clip is ready to go! Open ClipProfitAI for the caption.` });
        }, delay);
      }
      return [newDraft, ...prev];
    });
  }, [notifGranted]);

  const removeDraft = useCallback((id) => {
    setDrafts(prev => prev.filter(d => d.id !== id));
  }, []);

  const readyCount = drafts.filter(d => new Date(d.postAt) <= new Date()).length;

  const TABS = [
    { id: "today",       label: "⚡ Today"        },
    { id: "schedule",    label: "📅 Schedule"     },
    { id: "suggestions", label: "🎬 Clips"        },
    { id: "predictor",   label: "🎯 Predictor"   },
    { id: "drafts",      label: `📋 Drafts${drafts.length > 0 ? ` (${drafts.length})` : ""}` },
    { id: "revenue",     label: "💰 Revenue"      },
    { id: "research",    label: "🔍 Research"     },
  ];

  const [researchLoading, setResearchLoading] = useState(false);
  const [researchInsight, setResearchInsight] = useState("");

  const handleResearch = async () => {
    setResearchLoading(true); setResearchInsight("");
    const result = await callClaude(`You are a streaming clip monetization expert. Give a concise briefing (6-8 bullet points) on what streaming clip content is going VIRAL right now in 2025-2026 for TikTok, Instagram Reels, and YouTube Shorts. Focus on DeentheGreat and Kick streamers specifically. Include: top content types, estimated CPM by niche, trending formats, best platforms for each niche. Format as bullet points starting with emoji.`, 1000);
    setResearchInsight(result);
    setResearchLoading(false);
  };

  return (
    <div style={{ minHeight: "100vh", background: "#0A0A12", fontFamily: "'Inter', -apple-system, sans-serif", color: "#fff" }}>
      {/* Header */}
      <div style={{ background: "#0F0F20", borderBottom: "1px solid #1A1A30", padding: "14px 20px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 10, marginBottom: 12 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: "linear-gradient(135deg, #7C3AED, #4F46E5)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 17 }}>⚡</div>
            <div>
              <div style={{ fontSize: 20, fontWeight: 900, letterSpacing: "-0.02em" }}>
                ClipProfit<span style={{ color: "#7C3AED" }}>AI</span>
              </div>
              <div style={{ color: "#404070", fontSize: 11 }}>Find · Predict · Caption · Schedule · Profit</div>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            {readyCount > 0 && (
              <div style={{ background: "#00C85322", border: "1px solid #00C85344", color: "#00C853", borderRadius: 8, padding: "5px 10px", fontSize: 12, fontWeight: 700 }}>
                🟢 {readyCount} ready to post
              </div>
            )}
            {!notifGranted && (
              <button onClick={requestNotif} style={{
                background: "#1A1A3E", color: "#7C3AED", border: "1px solid #7C3AED44",
                borderRadius: 8, padding: "6px 12px", fontSize: 12, fontWeight: 600, cursor: "pointer",
              }}>🔔 Enable Reminders</button>
            )}
            {notifGranted && <span style={{ color: "#00C853", fontSize: 12 }}>🔔 Reminders ON</span>}
            <button onClick={handleRefresh} disabled={isRefreshing} style={{
              background: isRefreshing ? "#1A1A3E" : "#12121E",
              color: isRefreshing ? "#7C3AED" : "#5050A0",
              border: "1px solid #2A2A4A", borderRadius: 8,
              padding: "6px 12px", fontSize: 12, fontWeight: 600, cursor: isRefreshing ? "not-allowed" : "pointer",
            }}>
              {isRefreshing ? "⏳ Updating..." : "🔄 Refresh"}
            </button>
            {lastUpdated && !isRefreshing && (
              <span style={{ color: "#303050", fontSize: 11 }}>
                Updated {lastUpdated.toLocaleTimeString([], {hour: "2-digit", minute:"2-digit"})}
              </span>
            )}
            {refreshError && <span style={{ color: "#FF4444", fontSize: 11 }}>⚠️ Update failed</span>}
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              background: tab === t.id ? "#7C3AED" : "transparent",
              color: tab === t.id ? "#fff" : "#5050A0",
              border: `1px solid ${tab === t.id ? "#7C3AED" : "#2A2A4A"}`,
              borderRadius: 8, padding: "6px 13px", fontWeight: 600, cursor: "pointer", fontSize: 12,
            }}>{t.label}</button>
          ))}
        </div>
      </div>

      {/* Tab content */}
      <div style={{ height: "calc(100vh - 120px)", overflow: tab === "suggestions" ? "hidden" : "auto" }}>
        {tab === "today"       && <DailyWorkflow streamers={liveStreamers} />}
        {tab === "schedule"    && <SmartSchedule streamers={liveStreamers} />}
        {tab === "suggestions" && <ClipSuggestions drafts={drafts} onAddDraft={addDraft} streamers={liveStreamers} />}
        {tab === "predictor"   && <ClipPredictor />}
        {tab === "drafts"      && <DraftQueue drafts={drafts} onRemove={removeDraft} />}
        {tab === "revenue"     && <RevenueEstimator />}
        {tab === "research"    && (
          <div style={{ maxWidth: 760, margin: "0 auto", padding: 20 }}>
            <h2 style={{ color: "#E0E0FF", margin: "0 0 6px" }}>🔍 AI Market Research</h2>
            <p style={{ color: "#5050A0", fontSize: 13, margin: "0 0 18px" }}>Live market intelligence — what's profitable right now for Kick clip pages.</p>
            <button onClick={handleResearch} disabled={researchLoading} style={{
              width: "100%", background: researchLoading ? "#1A1A3E" : "linear-gradient(135deg, #7C3AED, #4F46E5)",
              color: "#fff", border: "none", borderRadius: 10, padding: "13px", fontWeight: 800, fontSize: 14,
              cursor: researchLoading ? "not-allowed" : "pointer", marginBottom: 20,
            }}>
              {researchLoading ? "⚡ Researching..." : "🚀 Run AI Market Research"}
            </button>
            {researchInsight && (
              <div style={{ background: "#12121E", border: "1px solid #2A2A4A", borderRadius: 14, padding: 22 }}>
                <div style={{ color: "#7C3AED", fontWeight: 700, fontSize: 12, marginBottom: 10 }}>MARKET INTELLIGENCE REPORT</div>
                <div style={{ color: "#C0C0E0", fontSize: 13, lineHeight: 1.8, whiteSpace: "pre-wrap" }}>{researchInsight}</div>
              </div>
            )}
            {!researchInsight && !researchLoading && (
              <div style={{ textAlign: "center", padding: "50px", color: "#252540" }}>
                <div style={{ fontSize: 44, marginBottom: 12 }}>📡</div>
                <div>Click above to scan the current market</div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
