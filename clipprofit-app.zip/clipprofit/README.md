# ClipProfitAI 🎬⚡

Find, predict, caption and schedule viral streaming clips — fully AI-powered.

## Deploy to Vercel (10 minutes)

### Step 1 — Create a free Vercel account
Go to https://vercel.com and sign up (free, no credit card).

### Step 2 — Install Vercel CLI (on your computer)
```
npm install -g vercel
```

### Step 3 — Deploy
Unzip this folder, open Terminal inside it, then run:
```
vercel
```
Follow the prompts. When asked "Set up and deploy?" say Yes.
Vercel gives you a live URL like: https://clipprofit-ai.vercel.app

### Step 4 — Install on your iPhone
1. Open the URL in **Safari** (must be Safari, not Chrome)
2. Tap the **Share** button (box with arrow)
3. Tap **"Add to Home Screen"**
4. Tap **Add**
5. Done — ClipProfitAI is now on your home screen like a real app!

### Step 5 — Add your Anthropic API Key
The app calls the Claude API. Add your key in Vercel:
1. Go to vercel.com → your project → Settings → Environment Variables
2. Add: REACT_APP_ANTHROPIC_KEY = your_key_here
3. Redeploy

Get a free API key at: https://console.anthropic.com

## Features
- 🎬 Clip Finder — AI suggests what clips to find and where
- 🎯 Clip Predictor — scores any clip before you invest time
- 📋 Draft Queue — schedules posts with push notification reminders
- 💰 Revenue Estimator — projects monthly earnings as you scale
- 🔍 AI Market Research — live intelligence on what's profitable

## Scaling Roadmap
- Month 1: 1 page (DeentheGreat), 3 posts/day → $200–500/mo
- Month 2: Add xQc or Speed page → $500–1,500/mo
- Month 3–4: 5 pages → $2,000–5,000/mo
- Month 6+: 10 pages → $5,000–15,000+/mo
